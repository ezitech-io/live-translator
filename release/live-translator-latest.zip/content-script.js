"use strict";
(() => {
  // node_modules/@quasar/app-vite/exports/bex/private/bex-bridge.js
  var portNameRE = /^background$|^app$|^content@/;
  var { runtime } = false ? browser : chrome;
  function getRandomId(max) {
    return Math.floor(Math.random() * max);
  }
  var BexBridge = class {
    // Public properties
    /** @type {string} */
    portName = null;
    /** @type {boolean} */
    isConnected = false;
    /** @type {{ type: 'on' | 'once', callback: (message: Message) => void }[]} */
    listeners = {};
    /** @type {{ [portName: string]: chrome.runtime.Port }} */
    portMap = {};
    /** @type {string[]} */
    portList = [];
    /** @type {{ [id: string]: { portName: string, resolve: (payload: any) => void, reject: (err: any) => void } }} */
    messageMap = {};
    /** @type {{ [id: string]: { portName: string, number: number, messageType: string, messageProps: any, payload: any[] } }} */
    chunkMap = {};
    // Private properties
    /** @type {'background' | 'content' | 'app'} */
    #type;
    /** @type {boolean} */
    #debug = false;
    /** @type {string} */
    #banner;
    /**
     * @param {{ type: 'background' | 'content' | 'app', name?: string, debug?: boolean }} options
     */
    constructor({ type, name = "", debug }) {
      this.portName = type;
      this.#type = type;
      if (type === "content") {
        this.portName = `${type}@${name}-${getRandomId(1e4)}`;
      }
      this.#banner = `[QBex|${this.portName}]`;
      this.#debug = debug === true;
      if (type !== "background") {
        this.on("@quasar:ports", ({ payload }) => {
          this.portList = payload.portList;
          if (payload.removed !== void 0) {
            this.#cleanupPort(payload.removed);
          }
        });
        return;
      }
      this.isConnected = true;
      const onPacket = this.#onPacket.bind(this);
      runtime.onConnect.addListener((port) => {
        if (portNameRE.test(port.name) === false) return;
        if (this.portMap[port.name] !== void 0) {
          this.warn(
            `Connection with "${port.name}" already exists. Disconnecting the previous one and connecting the new one.`
          );
          this.portMap[port.name].disconnect();
          this.#cleanupPort(port.name);
        }
        this.portMap[port.name] = port;
        port.onMessage.addListener(onPacket);
        port.onDisconnect.addListener(() => {
          port.onMessage.removeListener(onPacket);
          this.#cleanupPort(port.name);
          this.log(`Closed connection with ${port.name}.`);
          this.#onPortChange({ removed: port.name });
        });
        this.log(`Opened connection with ${port.name}.`);
        this.#onPortChange({ added: port.name });
      });
    }
    /**
     * @returns {Promise<void>}
     */
    connectToBackground() {
      if (this.#type === "background") {
        return Promise.reject("The background script itself does not need to connect");
      }
      if (this.isConnected === true) {
        return Promise.reject("The bridge is already connected");
      }
      const portToBackground = runtime.connect({ name: this.portName });
      return new Promise((resolve, reject) => {
        const onPacket = (packet) => {
          if (this.isConnected === false) {
            this.isConnected = true;
            this.log("Connected to the background script.");
            this.portMap = { background: portToBackground };
            resolve();
          }
          this.#onPacket(packet);
        };
        const onDisconnect = () => {
          if (runtime.lastError?.message?.indexOf("Could not establish connection") !== -1) {
            this.isConnected = false;
            portToBackground.onMessage.removeListener(onPacket);
            portToBackground.onMessage.removeListener(onDisconnect);
            reject("Could not connect to the background script.");
            return;
          }
          this.isConnected = false;
          for (const id in this.messageMap) {
            const item = this.messageMap[id];
            item.reject("Connection was closed");
          }
          this.portMap = {};
          this.portList = [];
          this.messageMap = {};
          this.chunkMap = {};
          this.log("Closed connection with the background script.");
        };
        portToBackground.onMessage.addListener(onPacket);
        portToBackground.onDisconnect.addListener(onDisconnect);
      });
    }
    /**
     * @returns {Promise<void>}
     */
    disconnectFromBackground() {
      if (this.#type === "background") {
        return Promise.reject("Background script does not need to disconnect");
      }
      if (this.isConnected === false) {
        return Promise.reject("Tried to disconnect from the background script but the port was not connected");
      }
      this.portMap.background.disconnect();
      delete this.portMap.background;
      this.isConnected = false;
      return Promise.resolve();
    }
    /**
     * @param {string} event
     * @param {(message: Message) => void} callback
     */
    on(event, callback) {
      if (!event) {
        this.warn("Tried add listener but no event specified.");
        return;
      }
      if (typeof callback !== "function") {
        this.warn("Tried add listener but no valid callback function specified.");
        return;
      }
      const target = this.listeners[event] || (this.listeners[event] = []);
      target.push({ type: "on", callback });
      this.log(`Added a listener for event: "${event}".`);
    }
    /**
     * @param {string} event
     * @param {(message: Message) => void} callback
     */
    once(event, callback) {
      if (!event) {
        this.warn("Tried add listener but no event specified.");
        return;
      }
      if (typeof callback !== "function") {
        this.warn("Tried add listener but no valid callback function specified.");
        return;
      }
      const target = this.listeners[event] || (this.listeners[event] = []);
      target.push({ type: "once", callback });
      this.log(`Added a one-time listener for event: "${event}".`);
    }
    /**
     * @param {string} event
     * @param {(message: Message) => void} callback
     */
    off(event, callback) {
      if (!event) {
        this.warn("Tried to remove listeners but no event specified.");
        return;
      }
      const list = this.listeners[event];
      if (list === void 0) {
        this.warn(`Tried to remove listener for "${event}" event but there is no such listener attached.`);
        return;
      }
      if (callback === void 0) {
        if (event.startsWith("@quasar:")) {
          this.listeners[event] = [list[0]];
        } else {
          delete this.listeners[event];
        }
        this.log(`Stopped listening for "${event}".`);
        return;
      }
      if (typeof callback !== "function") {
        this.warn("Tried to remove listener but the callback specified is not a function.");
        return;
      }
      const liveEvents = list.filter((entry) => entry.callback !== callback);
      if (liveEvents.length !== 0) {
        this.listeners[event] = liveEvents;
        this.log(`Removed a listener for: "${event}".`);
      } else {
        delete this.listeners[event];
        this.log(`Stopped listening for: "${event}".`);
      }
    }
    /**
     * @param {{ event: string, to: string, payload: any } | undefined} param
     * @returns {Promise<any>} response payload
     */
    async send({ event, to, payload } = {}) {
      if (this.isConnected === false) {
        throw new Error("Tried to send message but the bridge is not connected. Please connect it first.");
      }
      if (!event) {
        throw new Error('Tried to send message with no "event" prop specified');
      }
      if (!to) {
        throw new Error('Tried to send message with no "to" prop specified');
      }
      if (this.portList.includes(to) === false) {
        throw new Error(
          this.#type === "background" ? `Tried to send message to "${to}" but there is no such port registered` : `Tried to send message to "${to}" but the port to background is not available to send through`
        );
      }
      const id = getRandomId(1e6);
      await this.#sendMessage({
        id,
        to,
        payload,
        messageType: "event-send",
        messageProps: { event }
      });
      if (this.portList.includes(to) === false) {
        throw new Error(`Connection to "${to}" was closed while waiting for a response`);
      }
      return new Promise((resolve, reject) => {
        this.messageMap[id] = {
          portName: to,
          resolve: (responsePayload) => {
            delete this.messageMap[id];
            resolve(responsePayload);
          },
          reject: (err) => {
            delete this.messageMap[id];
            reject(err);
          }
        };
      });
    }
    /**
     * @param {boolean} value
     */
    setDebug(value) {
      this.#debug = value === true;
    }
    log(...args) {
      if (this.#debug !== true || args.length === 0) return;
      const lastArg = args[args.length - 1];
      if (lastArg !== void 0 && Object(lastArg) === lastArg) {
        const log = `${this.#banner} ${args.slice(0, -1).join(" ")} (click to expand)`;
        console.groupCollapsed(log);
        console.dir(lastArg);
        console.groupEnd(log);
      } else {
        console.log(this.#banner, ...args);
      }
    }
    warn(...args) {
      if (args.length === 0) return;
      const lastArg = args[args.length - 1];
      if (lastArg !== void 0 && Object(lastArg) === lastArg) {
        console.warn(this.#banner, ...args.slice(0, -1));
        const group = "The above warning details (click to expand)";
        console.groupCollapsed(group);
        console.dir(lastArg);
        console.groupEnd(group);
      } else {
        console.warn(this.#banner, ...args);
      }
    }
    /**
     * Should be used only by the background script
     * @param {{ added?: string } | { removed?: string }} reason
     */
    #onPortChange(reason) {
      this.portList = Object.keys(this.portMap);
      const list = ["background", ...this.portList];
      for (const portName of this.portList) {
        this.send({
          event: "@quasar:ports",
          to: portName,
          payload: {
            portList: list.filter((name) => name !== portName),
            ...reason
          }
        }).catch((err) => {
          this.warn(
            `Failed to inform "${portName}" about the port list.`,
            err
          );
        });
      }
    }
    /**
     * @param {Message} message
     */
    async #triggerMessageEvent(message) {
      const list = this.listeners[message.event];
      if (list === void 0) return;
      const plural = list.length > 1 ? "s" : "";
      this.log(
        `Triggering ${list.length} listener${plural} for event: "${message.event}".`,
        { message, listeners: list }
      );
      let responsePayload;
      for (const { type, callback } of list.slice(0)) {
        if (type === "once") {
          this.off(message.event, callback);
        }
        try {
          if (responsePayload === void 0) {
            const value = callback(message);
            responsePayload = value instanceof Promise ? await value : value;
          } else {
            callback(message);
          }
        } catch (err) {
          this.warn(
            `Error while triggering listener${plural} for event: "${message.event}".`,
            { error: err, message, listener: { type, callback } }
          );
          return Promise.reject(err);
        }
      }
      return responsePayload;
    }
    /**
     * @param {string} portName
     */
    #cleanupPort(portName) {
      for (const id in this.chunkMap) {
        const packet = this.chunkMap[id];
        if (packet.portName === portName) {
          delete this.chunkMap[id];
        }
      }
      for (const id in this.messageMap) {
        const packet = this.messageMap[id];
        if (packet.portName === portName) {
          packet.reject("Connection was closed");
        }
      }
      delete this.portMap[portName];
    }
    #onPacket(packet) {
      if (Object(packet) !== packet || packet.id === void 0 || packet.from === void 0 || packet.to === void 0 || packet.type === void 0) {
        this.log(
          "Received a message that does not appear to be emitted by a Quasar bridge or is malformed.",
          packet
        );
        return;
      }
      this.log(
        `Received message of type "${packet.type}" from "${packet.from}".`,
        packet
      );
      if (packet.to !== this.portName) {
        this.#sendPacket(packet).catch((err) => {
          this.warn(
            `Failed to forward message of type "${packet.type}" from "${packet.from}" to "${packet.to}".`,
            err
          );
          this.#sendMessage({
            id: packet.id,
            to: packet.from,
            messageType: "event-response",
            messageProps: {
              error: {
                message: err.message,
                stack: err.stack || "no stack available"
              },
              quiet: true
            }
          });
        });
        return;
      }
      if (packet.type === "full") {
        this.#onMessage({
          id: packet.id,
          from: packet.from,
          to: packet.to,
          payload: packet.payload,
          type: packet.messageType,
          props: packet.messageProps
        });
        return;
      }
      if (packet.type === "chunk") {
        const chunk = this.chunkMap[packet.id];
        if (chunk === void 0) {
          if (packet.chunkIndex !== void 0) {
            this.warn(
              "Received an unregistered chunk.",
              packet
            );
            return;
          }
          this.chunkMap[packet.id] = {
            portName: packet.from,
            number: packet.chunksNumber,
            messageType: packet.messageType,
            messageProps: packet.messageProps,
            payload: []
          };
          return;
        }
        if (packet.chunkIndex !== chunk.payload.length) {
          this.warn(
            "Received an out of order chunk.",
            packet
          );
          delete this.chunkMap[packet.id];
          return;
        }
        chunk.payload.push(packet.payload);
        if (packet.chunkIndex === chunk.number - 1) {
          delete this.chunkMap[packet.id];
          this.#onMessage({
            id: packet.id,
            from: packet.from,
            to: packet.to,
            payload: chunk.payload,
            type: chunk.messageType,
            props: chunk.messageProps
          });
        }
        return;
      }
      if (packet.type === "chunk-abort") {
        delete this.chunkMap[packet.id];
        return;
      }
      this.warn(
        `Received an unknown message type: "${packet.type}".`
      );
    }
    #sendPacket(packet) {
      this.log(
        packet.from === this.portName ? `Sending message of type "${packet.type}" to "${packet.to}".` : `Forwarding message of type "${packet.type}" from "${packet.from}" to "${packet.to}".`,
        packet
      );
      const port = this.#type === "background" ? this.portMap[packet.to] : this.portMap.background;
      if (this.portList.includes(packet.to) === false) {
        return Promise.reject(
          `Tried to send message of type "${packet.type}" to "${packet.to}" but there is no such port registered`
        );
      }
      if (port === void 0) {
        return Promise.reject(
          this.#type === "background" ? `Tried to send message of type "${packet.type}" to "${packet.to}" but the port is not available` : `Tried to send message of type "${packet.type}" to "${packet.to}" but the port to background is not available to forward through`
        );
      }
      try {
        port.postMessage(packet);
      } catch (err) {
        this.warn(
          `Failed to send message to "${packet.to}".`,
          err
        );
        return Promise.reject(err);
      }
      return Promise.resolve();
    }
    /**
     * @param {{ id?: number, to: string, payload: any, messageType: "event-send" | "event-response", messageProps: any }} param
     */
    #sendMessage({
      id = getRandomId(1e6),
      to,
      payload,
      messageType,
      messageProps
    }) {
      if (Array.isArray(payload) === false) {
        return this.#sendPacket({
          id,
          from: this.portName,
          to,
          type: "full",
          payload,
          messageType,
          messageProps
        });
      }
      let promise = this.#sendPacket({
        id,
        from: this.portName,
        to,
        type: "chunk",
        chunksNumber: payload.length,
        messageType,
        messageProps
      });
      for (let i = 0; i < payload.length; i++) {
        promise = promise.then(() => this.#sendPacket({
          id,
          from: this.portName,
          to,
          type: "chunk",
          payload: payload[i],
          chunkIndex: i
        }));
      }
      return promise.catch((err) => {
        this.#sendPacket({
          id,
          from: this.portName,
          to,
          type: "chunk-abort"
        }).catch((err2) => {
          this.warn(
            `Failed to send a chunk-abort message to "${to}".`,
            err2
          );
        });
        return Promise.reject(err);
      });
    }
    #onMessage(message) {
      if (message.type === "event-response") {
        const target = this.messageMap[message.id];
        if (target === void 0) {
          if (message.props.quiet !== true) {
            this.warn(
              `Received a response for an unknown message id: "${message.id}".`,
              message
            );
          }
          return;
        }
        if (message.props.error !== void 0) {
          target.reject(message.props.error);
        } else {
          target.resolve(message.payload);
        }
        return;
      }
      if (message.type === "event-send") {
        this.#triggerMessageEvent({
          from: message.from,
          to: message.to,
          event: message.props.event,
          payload: message.payload
        }).then((returnPayload) => {
          this.#sendMessage({
            id: message.id,
            to: message.from,
            payload: returnPayload,
            messageType: "event-response",
            messageProps: {}
          });
        }).catch((err) => {
          this.#sendMessage({
            id: message.id,
            to: message.from,
            messageType: "event-response",
            messageProps: {
              error: {
                message: err.message,
                stack: err.stack || "no stack available"
              }
            }
          });
        });
        return;
      }
      this.warn(
        `Received a message with unknown type: "${message.type}".`,
        message
      );
    }
  };

  // node_modules/@quasar/app-vite/exports/bex/content.js
  if (false) {
    let scriptIsReloading = false;
    const scriptName = "content-script";
    const portName = `quasar@hmr/content-script/${scriptName}`;
    const banner = `[QBex|HMR] [${scriptName}]`;
    const onMessage = (message) => {
      if (message === "qbex:hmr:hello") {
        console.log(`${banner} Connected to background`);
        return;
      }
      if (message === "qbex:hmr:reload-content") {
        console.log(`${banner} Reload requested by background...`);
        scriptIsReloading = true;
        setTimeout(() => {
          window.location.reload();
        }, 100);
      }
    };
    const connect = () => {
      const port = chrome.runtime.connect({ name: portName });
      port.onMessage.addListener(onMessage);
      port.onDisconnect.addListener(() => {
        if (scriptIsReloading === true) return;
        port.onMessage.removeListener(onMessage);
        console.log(
          chrome.runtime.lastError?.message?.indexOf("Could not establish connection") !== -1 ? `${banner} Could not connect to background` : `${banner} Lost connection to background`
        );
        setTimeout(connect, 1e3);
      });
    };
    connect();
  }
  var scriptHasBridge = false;
  function createBridge({ debug } = {}) {
    if (scriptHasBridge === true) {
      console.error("Content script Quasar Bridge has already been created.");
      return;
    }
    scriptHasBridge = true;
    return new BexBridge({
      type: "content",
      name: "content-script",
      debug
    });
  }

  // src-bex/panel-resize.ts
  var PANEL_MIN_WIDTH = 360;
  var PANEL_MIN_HEIGHT = 320;
  var DEFAULT_PANEL_WIDTH_RATIO = 0.25;
  var DEFAULT_PANEL_HEIGHT_RATIO = 0.9;
  var ASSISTANT_MIN_WIDTH = 320;
  var ASSISTANT_MIN_HEIGHT = 360;
  function clampPanelSize(rect) {
    return {
      ...rect,
      width: Math.max(rect.width, PANEL_MIN_WIDTH),
      height: Math.max(rect.height, PANEL_MIN_HEIGHT)
    };
  }
  function getDefaultPanelRect(viewportWidth, viewportHeight) {
    const width = Math.max(PANEL_MIN_WIDTH, Math.floor(viewportWidth * DEFAULT_PANEL_WIDTH_RATIO));
    const height = Math.max(PANEL_MIN_HEIGHT, Math.floor(viewportHeight * DEFAULT_PANEL_HEIGHT_RATIO));
    const y = Math.max(0, Math.floor((viewportHeight - height) / 2));
    return {
      x: viewportWidth - width,
      y,
      width,
      height
    };
  }
  function getDefaultAssistantRect(viewportWidth, viewportHeight) {
    const width = 420;
    const height = 520;
    return {
      x: Math.max(0, Math.floor((viewportWidth - width) / 2)),
      y: Math.max(0, Math.floor((viewportHeight - height) / 2)),
      width,
      height
    };
  }
  function clampAssistantSize(rect) {
    return {
      ...rect,
      width: Math.max(rect.width, ASSISTANT_MIN_WIDTH),
      height: Math.max(rect.height, ASSISTANT_MIN_HEIGHT)
    };
  }
  function getDraggedPanelRect(currentRect, pointer, dragOffset2) {
    return {
      ...currentRect,
      x: pointer.x - dragOffset2.x,
      y: pointer.y - dragOffset2.y
    };
  }
  function getResizedPanelRect(startRect, edge, pointer, startPointer) {
    const deltaX = pointer.x - startPointer.x;
    const deltaY = pointer.y - startPointer.y;
    if (edge === "left") {
      const width = Math.max(PANEL_MIN_WIDTH, startRect.width - deltaX);
      const consumedDelta = startRect.width - width;
      return {
        ...startRect,
        x: startRect.x + consumedDelta,
        width
      };
    }
    if (edge === "right") {
      return {
        ...startRect,
        width: Math.max(PANEL_MIN_WIDTH, startRect.width + deltaX)
      };
    }
    if (edge === "top") {
      const height = Math.max(PANEL_MIN_HEIGHT, startRect.height - deltaY);
      const consumedDelta = startRect.height - height;
      return {
        ...startRect,
        y: startRect.y + consumedDelta,
        height
      };
    }
    return {
      ...startRect,
      height: Math.max(PANEL_MIN_HEIGHT, startRect.height + deltaY)
    };
  }

  // src-bex/content-script.ts
  if (document.getElementById("live-translator-icon")) {
    throw new Error("Live Translator already injected");
  }
  var panelIframe = null;
  var floatingIcon = null;
  var resizeHandles = {};
  var isPanelVisible = false;
  var panelRect = null;
  var isDragging = false;
  var dragOffset = { x: 0, y: 0 };
  var activeResizeEdge = null;
  var resizeStartPointer = { x: 0, y: 0 };
  var resizeStartRect = null;
  var assistantIframe = null;
  var isAssistantVisible = false;
  var assistantRect = null;
  var isAssistantDragging = false;
  var assistantDragOffset = { x: 0, y: 0 };
  function getExtensionOrigin() {
    return new URL(chrome.runtime.getURL("")).origin;
  }
  function getCurrentPanelRect() {
    if (panelRect) return panelRect;
    if (!panelIframe) return null;
    const rect = panelIframe.getBoundingClientRect();
    return {
      x: rect.left,
      y: rect.top,
      width: rect.width,
      height: rect.height
    };
  }
  function syncResizeHandlePositions() {
    const rect = getCurrentPanelRect();
    if (!rect) return;
    const leftHandle = resizeHandles.left;
    const rightHandle = resizeHandles.right;
    const topHandle = resizeHandles.top;
    const bottomHandle = resizeHandles.bottom;
    if (leftHandle) {
      leftHandle.style.left = `${Math.round(rect.x - 4)}px`;
      leftHandle.style.top = `${Math.round(rect.y)}px`;
      leftHandle.style.width = "8px";
      leftHandle.style.height = `${Math.round(rect.height)}px`;
    }
    if (rightHandle) {
      rightHandle.style.left = `${Math.round(rect.x + rect.width - 4)}px`;
      rightHandle.style.top = `${Math.round(rect.y)}px`;
      rightHandle.style.width = "8px";
      rightHandle.style.height = `${Math.round(rect.height)}px`;
    }
    if (topHandle) {
      topHandle.style.left = `${Math.round(rect.x)}px`;
      topHandle.style.top = `${Math.round(rect.y - 4)}px`;
      topHandle.style.width = `${Math.round(rect.width)}px`;
      topHandle.style.height = "8px";
    }
    if (bottomHandle) {
      bottomHandle.style.left = `${Math.round(rect.x)}px`;
      bottomHandle.style.top = `${Math.round(rect.y + rect.height - 4)}px`;
      bottomHandle.style.width = `${Math.round(rect.width)}px`;
      bottomHandle.style.height = "8px";
    }
  }
  function setResizeHandlesVisible(visible) {
    const display = visible ? "block" : "none";
    const edges = ["left", "right", "top", "bottom"];
    for (const edge of edges) {
      const handle = resizeHandles[edge];
      if (handle) {
        handle.style.display = display;
      }
    }
  }
  function applyPanelRect(rect) {
    if (!panelIframe) return;
    const nextRect = clampPanelSize(rect);
    panelRect = nextRect;
    panelIframe.style.left = `${Math.round(nextRect.x)}px`;
    panelIframe.style.top = `${Math.round(nextRect.y)}px`;
    panelIframe.style.width = `${Math.round(nextRect.width)}px`;
    panelIframe.style.height = `${Math.round(nextRect.height)}px`;
    panelIframe.style.right = "auto";
    panelIframe.style.bottom = "auto";
    syncResizeHandlePositions();
  }
  function createFloatingIcon() {
    const btn = document.createElement("button");
    btn.id = "live-translator-icon";
    btn.setAttribute("aria-label", "Live Translator");
    const icon = document.createElement("img");
    icon.src = chrome.runtime.getURL("icons/icon-128x128.png");
    icon.alt = "";
    icon.width = 24;
    icon.height = 24;
    btn.appendChild(icon);
    btn.addEventListener("click", togglePanel);
    document.body.appendChild(btn);
    return btn;
  }
  function createPanel() {
    const iframe = document.createElement("iframe");
    iframe.id = "live-translator-panel";
    iframe.src = chrome.runtime.getURL("www/index.html");
    iframe.setAttribute("allow", "microphone; display-capture; camera");
    document.body.appendChild(iframe);
    return iframe;
  }
  function onResizeHandleMouseDown(event) {
    const target = event.currentTarget;
    const edge = target?.dataset.edge;
    if (!edge) return;
    if (isDragging || !isPanelVisible) return;
    const currentRect = getCurrentPanelRect();
    if (!currentRect) return;
    event.preventDefault();
    event.stopPropagation();
    activeResizeEdge = edge;
    resizeStartPointer = {
      x: event.clientX,
      y: event.clientY
    };
    resizeStartRect = { ...currentRect };
    document.body.style.userSelect = "none";
  }
  function createResizeHandles() {
    const edges = ["left", "right", "top", "bottom"];
    for (const edge of edges) {
      const handle = document.createElement("div");
      handle.id = `live-translator-resize-handle-${edge}`;
      handle.className = `live-translator-resize-handle live-translator-resize-handle--${edge}`;
      handle.dataset.edge = edge;
      handle.setAttribute("aria-hidden", "true");
      handle.style.display = "none";
      handle.addEventListener("mousedown", onResizeHandleMouseDown);
      document.body.appendChild(handle);
      resizeHandles[edge] = handle;
    }
  }
  function startDrag(localClientX, localClientY) {
    if (!panelIframe || !isPanelVisible || activeResizeEdge) return;
    if (!Number.isFinite(localClientX) || !Number.isFinite(localClientY)) return;
    const currentRect = getCurrentPanelRect();
    if (!currentRect) return;
    isDragging = true;
    dragOffset = { x: localClientX, y: localClientY };
    panelRect = currentRect;
    document.body.style.userSelect = "none";
  }
  function handleDragMoveFromIframe(localClientX, localClientY) {
    if (!isDragging || !panelIframe) return;
    if (!Number.isFinite(localClientX) || !Number.isFinite(localClientY)) return;
    const iframeRect = panelIframe.getBoundingClientRect();
    const pointer = {
      x: iframeRect.left + localClientX,
      y: iframeRect.top + localClientY
    };
    const currentRect = getCurrentPanelRect();
    if (!currentRect) return;
    applyPanelRect(getDraggedPanelRect(currentRect, pointer, dragOffset));
  }
  function endPointerInteraction() {
    if (isAssistantDragging) {
      endAssistantDrag();
    }
    if (!isDragging && !activeResizeEdge) return;
    isDragging = false;
    activeResizeEdge = null;
    resizeStartRect = null;
    document.body.style.userSelect = "";
  }
  function onPointerMove(event) {
    if (isDragging) {
      const currentRect = getCurrentPanelRect();
      if (!currentRect) return;
      applyPanelRect(
        getDraggedPanelRect(
          currentRect,
          { x: event.clientX, y: event.clientY },
          dragOffset
        )
      );
      return;
    }
    if (isAssistantDragging && assistantRect) {
      applyAssistantRect(
        getDraggedPanelRect(
          assistantRect,
          { x: event.clientX, y: event.clientY },
          assistantDragOffset
        )
      );
      return;
    }
    if (!activeResizeEdge || !resizeStartRect) return;
    const nextRect = getResizedPanelRect(
      resizeStartRect,
      activeResizeEdge,
      { x: event.clientX, y: event.clientY },
      resizeStartPointer
    );
    applyPanelRect(nextRect);
  }
  function showPanel() {
    if (!panelIframe) {
      panelIframe = createPanel();
      if (!resizeHandles.left) {
        createResizeHandles();
      }
    }
    if (!panelRect) {
      panelRect = getDefaultPanelRect(window.innerWidth, window.innerHeight);
    }
    applyPanelRect(panelRect);
    panelIframe.classList.add("visible");
    setResizeHandlesVisible(true);
    isPanelVisible = true;
    if (floatingIcon) {
      floatingIcon.classList.add("panel-open");
    }
  }
  function hidePanel() {
    endPointerInteraction();
    if (panelIframe) {
      panelIframe.classList.remove("visible");
    }
    setResizeHandlesVisible(false);
    isPanelVisible = false;
    if (floatingIcon) {
      floatingIcon.classList.remove("panel-open");
    }
  }
  function closePanel() {
    endPointerInteraction();
    if (panelIframe) {
      panelIframe.remove();
      panelIframe = null;
    }
    const edges = ["left", "right", "top", "bottom"];
    for (const edge of edges) {
      const handle = resizeHandles[edge];
      if (handle) {
        handle.removeEventListener("mousedown", onResizeHandleMouseDown);
        handle.remove();
        delete resizeHandles[edge];
      }
    }
    isPanelVisible = false;
    if (floatingIcon) {
      floatingIcon.classList.remove("panel-open");
    }
  }
  function togglePanel() {
    if (isPanelVisible) {
      hidePanel();
    } else {
      showPanel();
    }
  }
  function isFiniteNumber(value) {
    return typeof value === "number" && Number.isFinite(value);
  }
  function createAssistantPanel() {
    const iframe = document.createElement("iframe");
    iframe.id = "live-translator-assistant-panel";
    iframe.src = chrome.runtime.getURL("www/index.html#/assistant");
    document.body.appendChild(iframe);
    return iframe;
  }
  function applyAssistantRect(rect) {
    if (!assistantIframe) return;
    const nextRect = clampAssistantSize(rect);
    assistantRect = nextRect;
    assistantIframe.style.left = `${Math.round(nextRect.x)}px`;
    assistantIframe.style.top = `${Math.round(nextRect.y)}px`;
    assistantIframe.style.width = `${Math.round(nextRect.width)}px`;
    assistantIframe.style.height = `${Math.round(nextRect.height)}px`;
    assistantIframe.style.right = "auto";
    assistantIframe.style.bottom = "auto";
  }
  function showAssistant() {
    if (!assistantIframe) {
      assistantIframe = createAssistantPanel();
    }
    if (!assistantRect) {
      assistantRect = getDefaultAssistantRect(window.innerWidth, window.innerHeight);
    }
    applyAssistantRect(assistantRect);
    assistantIframe.classList.add("visible");
    isAssistantVisible = true;
  }
  function hideAssistant() {
    if (isAssistantDragging) {
      isAssistantDragging = false;
      document.body.style.userSelect = "";
    }
    if (assistantIframe) {
      assistantIframe.classList.remove("visible");
    }
    isAssistantVisible = false;
  }
  function closeAssistant() {
    hideAssistant();
    if (assistantIframe) {
      assistantIframe.remove();
      assistantIframe = null;
    }
  }
  function startAssistantDrag(localClientX, localClientY) {
    if (!assistantIframe || !isAssistantVisible) return;
    if (!Number.isFinite(localClientX) || !Number.isFinite(localClientY)) return;
    isAssistantDragging = true;
    assistantDragOffset = { x: localClientX, y: localClientY };
    document.body.style.userSelect = "none";
  }
  function handleAssistantDragMoveFromIframe(localClientX, localClientY) {
    if (!isAssistantDragging || !assistantIframe || !assistantRect) return;
    if (!Number.isFinite(localClientX) || !Number.isFinite(localClientY)) return;
    const iframeRect = assistantIframe.getBoundingClientRect();
    const pointer = {
      x: iframeRect.left + localClientX,
      y: iframeRect.top + localClientY
    };
    applyAssistantRect(getDraggedPanelRect(assistantRect, pointer, assistantDragOffset));
  }
  function endAssistantDrag() {
    if (!isAssistantDragging) return;
    isAssistantDragging = false;
    document.body.style.userSelect = "";
  }
  function duckPageMediaVolume(volume) {
    const clampedVolume = Math.max(0, Math.min(1, volume));
    const mediaElements = document.querySelectorAll("audio, video");
    console.log("[Live Translator] Ducking", mediaElements.length, "media elements to volume:", clampedVolume);
    for (const el of mediaElements) {
      const media = el;
      media.volume = clampedVolume;
    }
  }
  function handlePanelMessage(event) {
    const origin = getExtensionOrigin();
    if (event.origin !== origin) return;
    const data = event.data;
    if (!data?.type) return;
    switch (data.type) {
      case "MINIMIZE_PANEL":
        hidePanel();
        break;
      case "CLOSE_PANEL":
        closePanel();
        break;
      case "PANEL_DRAG_START":
        if (isFiniteNumber(data.localClientX) && isFiniteNumber(data.localClientY)) {
          startDrag(data.localClientX, data.localClientY);
        }
        break;
      case "PANEL_DRAG_MOVE":
        if (isFiniteNumber(data.localClientX) && isFiniteNumber(data.localClientY)) {
          handleDragMoveFromIframe(data.localClientX, data.localClientY);
        }
        break;
      case "PANEL_DRAG_END":
        endPointerInteraction();
        break;
      case "TTS_DUCK_VOLUME":
        if (typeof data.volume === "number" && Number.isFinite(data.volume)) {
          duckPageMediaVolume(data.volume);
        }
        break;
      case "PANEL_READY":
        break;
      case "ASSISTANT_OPEN":
        showAssistant();
        break;
      case "ASSISTANT_CLOSE":
        closeAssistant();
        break;
      case "ASSISTANT_DRAG_START":
        if (isFiniteNumber(data.localClientX) && isFiniteNumber(data.localClientY)) {
          startAssistantDrag(data.localClientX, data.localClientY);
        }
        break;
      case "ASSISTANT_DRAG_MOVE":
        if (isFiniteNumber(data.localClientX) && isFiniteNumber(data.localClientY)) {
          handleAssistantDragMoveFromIframe(data.localClientX, data.localClientY);
        }
        break;
      case "ASSISTANT_DRAG_END":
        endAssistantDrag();
        break;
      case "ASSISTANT_READY":
        break;
    }
  }
  window.addEventListener("message", handlePanelMessage);
  window.addEventListener("mousemove", onPointerMove);
  window.addEventListener("mouseup", endPointerInteraction);
  window.addEventListener("resize", () => {
    if (panelRect && panelIframe) {
      applyPanelRect(panelRect);
    }
    if (assistantRect && assistantIframe) {
      applyAssistantRect(assistantRect);
    }
  });
  floatingIcon = createFloatingIcon();
  var bridge = createBridge({ debug: false });
  bridge.on("panel.toggle", () => {
    togglePanel();
  });
  bridge.connectToBackground().then(() => {
    console.log("[Live Translator] Content script connected");
  }).catch((err) => {
    console.error("[Live Translator] Failed to connect:", err);
  });
})();

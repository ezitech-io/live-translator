"use strict";
(() => {
  // src-bex/mic-interceptor.ts
  var LOG = "[MicInterceptor]";
  var virtualMic = null;
  var storedRealStream = null;
  function base64ToInt16Array(base64) {
    const binary = atob(base64);
    const byteLen = binary.length & ~1;
    const bytes = new Uint8Array(byteLen);
    for (let i = 0; i < byteLen; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return new Int16Array(bytes.buffer);
  }
  function int16ToFloat32(int16) {
    const float32 = new Float32Array(int16.length);
    for (let i = 0; i < int16.length; i++) {
      float32[i] = (int16[i] ?? 0) / 32768;
    }
    return float32;
  }
  function storeRealStream(stream) {
    storedRealStream = stream;
  }
  function wrapStream(realStream) {
    storedRealStream = realStream;
    if (virtualMic) {
      connectRealMic(realStream);
      return virtualMic.destination.stream;
    }
    const audioCtx = new AudioContext({ sampleRate: 24e3 });
    const destination = audioCtx.createMediaStreamDestination();
    const micGain = audioCtx.createGain();
    micGain.gain.setValueAtTime(0, audioCtx.currentTime);
    micGain.connect(destination);
    virtualMic = {
      audioCtx,
      destination,
      micGain,
      micSource: null,
      realStream: null,
      nextPlayTime: 0,
      isInjecting: false,
      lastSourceNode: null,
      onInjectionDone: null
    };
    connectRealMic(realStream);
    console.log(LOG, "Virtual mic created (real mic permanently muted)");
    return destination.stream;
  }
  function connectRealMic(realStream) {
    if (!virtualMic) return;
    if (virtualMic.micSource) {
      try {
        virtualMic.micSource.disconnect();
      } catch {
      }
    }
    virtualMic.realStream = realStream;
    virtualMic.micSource = virtualMic.audioCtx.createMediaStreamSource(realStream);
    virtualMic.micSource.connect(virtualMic.micGain);
    console.log(LOG, "Real mic connected through GainNode");
  }
  function activateVirtualMic() {
    if (!storedRealStream) return null;
    const virtualStream = wrapStream(storedRealStream);
    const track = virtualStream.getAudioTracks()[0] ?? null;
    if (track) {
      console.log(LOG, "Virtual mic activated \u2014 virtual track ready for replaceTrack");
    }
    return track;
  }
  function deactivateVirtualMic() {
    if (!virtualMic) return;
    try {
      virtualMic.micSource?.disconnect();
    } catch {
    }
    try {
      virtualMic.micGain.disconnect();
    } catch {
    }
    try {
      void virtualMic.audioCtx.close();
    } catch {
    }
    virtualMic = null;
    console.log(LOG, "Virtual mic deactivated (stored stream preserved for re-use)");
  }
  function getVirtualTrack() {
    return virtualMic?.destination.stream.getAudioTracks()[0] ?? null;
  }
  function getStoredRealTrack() {
    return storedRealStream?.getAudioTracks()[0] ?? null;
  }
  function startInjection(onDone) {
    if (!virtualMic) return;
    virtualMic.isInjecting = true;
    virtualMic.lastSourceNode = null;
    virtualMic.onInjectionDone = onDone;
  }
  function injectAudioChunk(pcm16Base64, sampleRate) {
    if (!virtualMic) return;
    try {
      if (virtualMic.audioCtx.state === "suspended") {
        void virtualMic.audioCtx.resume();
      }
      const int16 = base64ToInt16Array(pcm16Base64);
      const float32 = int16ToFloat32(int16);
      const buffer = virtualMic.audioCtx.createBuffer(1, float32.length, sampleRate);
      buffer.getChannelData(0).set(float32);
      const source = virtualMic.audioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(virtualMic.destination);
      const now = virtualMic.audioCtx.currentTime;
      const startTime = Math.max(now, virtualMic.nextPlayTime);
      source.start(startTime);
      virtualMic.nextPlayTime = startTime + buffer.duration;
      virtualMic.lastSourceNode = source;
    } catch (err) {
      console.warn(LOG, "Failed to inject audio chunk:", err);
    }
  }
  function stopInjection() {
    if (!virtualMic) return;
    virtualMic.isInjecting = false;
    const lastNode = virtualMic.lastSourceNode;
    const capturedDone = virtualMic.onInjectionDone;
    virtualMic.onInjectionDone = null;
    if (!capturedDone) return;
    const remainingMs = Math.max(0, (virtualMic.nextPlayTime - virtualMic.audioCtx.currentTime) * 1e3);
    if (remainingMs <= 0 || !lastNode) {
      capturedDone();
      return;
    }
    let resolved = false;
    const resolve = () => {
      if (resolved) return;
      resolved = true;
      capturedDone();
    };
    lastNode.addEventListener("ended", resolve, { once: true });
    setTimeout(resolve, remainingMs + 500);
  }
  function isActive() {
    return virtualMic !== null;
  }
  function dispose() {
    if (virtualMic) {
      try {
        virtualMic.micSource?.disconnect();
      } catch {
      }
      try {
        virtualMic.micGain.disconnect();
      } catch {
      }
      try {
        void virtualMic.audioCtx.close();
      } catch {
      }
      virtualMic = null;
      console.log(LOG, "Virtual mic disposed");
    }
    storedRealStream = null;
  }

  // src-bex/mic-interceptor-inject.ts
  var LOG2 = "[MicInterceptor:MAIN]";
  var shouldWrap = false;
  var originalGetUserMedia = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  navigator.mediaDevices.getUserMedia = async function(constraints) {
    const stream = await originalGetUserMedia(constraints);
    if (constraints?.audio) {
      if (shouldWrap) {
        try {
          const wrapped = wrapStream(stream);
          console.log(LOG2, "getUserMedia intercepted \u2014 returning virtual mic stream");
          reportStatus();
          return wrapped;
        } catch (err) {
          console.warn(LOG2, "Failed to wrap stream, returning original:", err);
        }
      } else {
        storeRealStream(stream);
        console.log(LOG2, "getUserMedia passthrough \u2014 returning original stream (AEC intact)");
      }
      reportStatus();
    }
    return stream;
  };
  console.log(LOG2, "getUserMedia patched (deferred mode)");
  var audioSenders = /* @__PURE__ */ new Set();
  var trackedPCs = /* @__PURE__ */ new Set();
  if (typeof RTCPeerConnection !== "undefined") {
    const NativeRTCPeerConnection = window.RTCPeerConnection;
    window.RTCPeerConnection = new Proxy(NativeRTCPeerConnection, {
      construct(target, args, newTarget) {
        const pc = Reflect.construct(target, args, newTarget);
        trackedPCs.add(pc);
        console.log(LOG2, "PeerConnection created, tracked:", trackedPCs.size);
        pc.addEventListener("connectionstatechange", () => {
          if (pc.connectionState === "closed" || pc.connectionState === "failed") {
            trackedPCs.delete(pc);
          }
        });
        return pc;
      }
    });
    const addTrackDescriptor = Object.getOwnPropertyDescriptor(NativeRTCPeerConnection.prototype, "addTrack");
    const originalAddTrack = addTrackDescriptor?.value;
    if (originalAddTrack) {
      NativeRTCPeerConnection.prototype.addTrack = function(track, ...streams) {
        const sender = originalAddTrack.call(this, track, ...streams);
        if (track.kind === "audio") {
          audioSenders.add(sender);
          console.log(LOG2, "Audio sender tracked via addTrack, total:", audioSenders.size);
          if (shouldWrap) {
            const virtualTrack = getVirtualTrack();
            if (virtualTrack) {
              void sender.replaceTrack(virtualTrack).catch(
                (err) => console.warn(LOG2, "Auto-replaceTrack on new sender failed:", err)
              );
            }
          }
        }
        return sender;
      };
      console.log(LOG2, "RTCPeerConnection.addTrack patched");
    } else {
      console.warn(LOG2, "Could not patch addTrack \u2014 descriptor not found");
    }
    console.log(LOG2, "RTCPeerConnection constructor patched via Proxy");
  }
  function discoverAudioSenders() {
    let discovered = 0;
    for (const pc of trackedPCs) {
      try {
        if (pc.connectionState === "closed" || pc.connectionState === "failed") {
          trackedPCs.delete(pc);
          continue;
        }
        for (const sender of pc.getSenders()) {
          if (sender.track?.kind === "audio" && !audioSenders.has(sender)) {
            audioSenders.add(sender);
            discovered++;
          }
        }
      } catch {
      }
    }
    if (discovered > 0) {
      console.log(LOG2, `Discovered ${discovered} audio sender(s) from ${trackedPCs.size} PC(s)`);
    }
  }
  async function replaceTrackOnAllSenders(newTrack) {
    discoverAudioSenders();
    if (audioSenders.size === 0) {
      console.warn(LOG2, "No audio senders found \u2014 replaceTrack skipped. PCs tracked:", trackedPCs.size);
      return;
    }
    const invalid = [];
    let replaced = 0;
    for (const sender of audioSenders) {
      try {
        await sender.replaceTrack(newTrack);
        replaced++;
      } catch (err) {
        console.warn(LOG2, "replaceTrack failed on sender:", err);
        invalid.push(sender);
      }
    }
    for (const s of invalid) audioSenders.delete(s);
    console.log(LOG2, `replaceTrack done \u2014 ${replaced} replaced, ${invalid.length} pruned, ${audioSenders.size} active`);
  }
  function detectPlatform() {
    const host = location.hostname;
    if (host.includes("meet.google.com")) return "meet";
    if (host.includes("zoom.us")) return "zoom";
    if (host.includes("teams.microsoft.com") || host.includes("teams.live.com")) return "teams";
    return "unknown";
  }
  function reportStatus() {
    window.postMessage({
      source: "live-translator-mic-interceptor",
      type: "VIRTUAL_MIC_STATUS",
      payload: {
        supported: true,
        active: isActive(),
        wrapping: shouldWrap,
        platform: detectPlatform(),
        senders: audioSenders.size,
        peerConnections: trackedPCs.size
      }
    }, "*");
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (data?.source !== "live-translator-panel-relay") return;
    switch (data.type) {
      case "ACTIVATE_VIRTUAL_MIC": {
        shouldWrap = true;
        const virtualTrack = activateVirtualMic();
        if (virtualTrack) {
          void replaceTrackOnAllSenders(virtualTrack);
          console.log(LOG2, "Virtual mic activated \u2014 senders:", audioSenders.size, "PCs:", trackedPCs.size);
        } else {
          console.warn(LOG2, "Virtual mic activation failed \u2014 no stored stream");
        }
        window.postMessage({
          source: "live-translator-mic-interceptor",
          type: "VIRTUAL_MIC_ACTIVATED",
          payload: { active: true }
        }, "*");
        reportStatus();
        break;
      }
      case "DEACTIVATE_VIRTUAL_MIC": {
        shouldWrap = false;
        const realTrack = getStoredRealTrack();
        if (realTrack) {
          void replaceTrackOnAllSenders(realTrack).then(() => {
            deactivateVirtualMic();
          });
        } else {
          deactivateVirtualMic();
        }
        console.log(LOG2, "Virtual mic deactivating \u2014 restoring real track");
        window.postMessage({
          source: "live-translator-mic-interceptor",
          type: "VIRTUAL_MIC_DEACTIVATED",
          payload: { active: false }
        }, "*");
        reportStatus();
        break;
      }
      case "START_AUDIO_INJECTION":
        startInjection(() => {
          window.postMessage({
            source: "live-translator-mic-interceptor",
            type: "AUDIO_INJECTION_DONE"
          }, "*");
        });
        break;
      case "INJECT_AUDIO_CHUNK":
        if (data.pcm16Base64 && data.sampleRate) {
          injectAudioChunk(data.pcm16Base64, data.sampleRate);
        }
        break;
      case "STOP_AUDIO_INJECTION":
        stopInjection();
        break;
      case "REQUEST_STATUS":
        reportStatus();
        break;
      case "DISPOSE":
        shouldWrap = false;
        dispose();
        break;
    }
  });
  reportStatus();
})();

(function () {
  let audio = null
  let currentDataUrl = null
  let currentVolume = 1.0

  function cleanup() {
    if (audio) {
      audio.onplay = null
      audio.onended = null
      audio.onerror = null
      audio.pause()
      audio = null
    }
    currentDataUrl = null
  }

  function stopPlayback() {
    cleanup()
  }

  async function playDataUrl(dataUrl, volume) {
    stopPlayback()

    return await new Promise((resolve, reject) => {
      audio = new Audio(dataUrl)
      currentDataUrl = dataUrl
      audio.volume = Math.max(0, Math.min(1, volume ?? currentVolume))

      audio.onended = () => {
        cleanup()
        resolve()
      }

      audio.onerror = () => {
        const err = audio && audio.error
          ? `Audio error code ${audio.error.code}: ${audio.error.message || 'unknown'}`
          : 'Unknown audio playback error'
        cleanup()
        reject(new Error(err))
      }

      audio.play().catch((err) => {
        cleanup()
        reject(err instanceof Error ? err : new Error('Audio play() rejected'))
      })
    })
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || typeof message !== 'object' || !message.type) return

    if (message.type === 'offscreen.tts.play') {
      const payload = message.payload || {}
      const dataUrl = payload.dataUrl
      if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:audio/')) {
        sendResponse({ ok: false, error: 'Invalid offscreen audio payload' })
        return
      }

      const volume = typeof payload.volume === 'number' ? payload.volume : currentVolume

      void playDataUrl(dataUrl, volume)
        .then(() => {
          sendResponse({ ok: true })
        })
        .catch((err) => {
          const messageText = err instanceof Error ? err.message : 'Offscreen playback failed'
          console.error('[TTS:Offscreen] Playback failed:', messageText)
          sendResponse({ ok: false, error: messageText })
        })
      return true
    }

    if (message.type === 'offscreen.tts.stop') {
      stopPlayback()
      sendResponse({ ok: true })
      return
    }

    if (message.type === 'offscreen.tts.setVolume') {
      const vol = typeof message.volume === 'number' ? Math.max(0, Math.min(1, message.volume)) : 1.0
      currentVolume = vol
      if (audio) {
        audio.volume = vol
      }
      sendResponse({ ok: true })
      return
    }
  })
})()

import { D as onMounted, P as watch, W as ref, _ as getCurrentInstance, v as h, w as onBeforeUnmount, x as nextTick } from "./vue.runtime.esm-bundler-Da8D7169.js";
import { b as createComponent, m as noop, p as listenOpts } from "./dom-DvzD_91u.js";
import { c as isRuntimeSsrPreHydration } from "./symbols-dSu0xIJX.js";
import { a as getVerticalScrollPosition, n as getHorizontalScrollPosition, r as getScrollTarget, s as scrollTargetProp } from "./_plugin-vue_export-helper-Ca_i4E4D.js";
//#region node_modules/quasar/src/components/scroll-observer/QScrollObserver.js
var { passive } = listenOpts;
var axisValues = [
	"both",
	"horizontal",
	"vertical"
];
var QScrollObserver_default = createComponent({
	name: "QScrollObserver",
	props: {
		axis: {
			type: String,
			validator: (v) => axisValues.includes(v),
			default: "vertical"
		},
		debounce: [String, Number],
		scrollTarget: scrollTargetProp
	},
	emits: ["scroll"],
	setup(props, { emit }) {
		const scroll = {
			position: {
				top: 0,
				left: 0
			},
			direction: "down",
			directionChanged: false,
			delta: {
				top: 0,
				left: 0
			},
			inflectionPoint: {
				top: 0,
				left: 0
			}
		};
		let clearTimer = null, localScrollTarget, parentEl;
		watch(() => props.scrollTarget, () => {
			unconfigureScrollTarget();
			configureScrollTarget();
		});
		function emitEvent() {
			clearTimer?.();
			const top = Math.max(0, getVerticalScrollPosition(localScrollTarget));
			const left = getHorizontalScrollPosition(localScrollTarget);
			const delta = {
				top: top - scroll.position.top,
				left: left - scroll.position.left
			};
			if (props.axis === "vertical" && delta.top === 0 || props.axis === "horizontal" && delta.left === 0) return;
			const curDir = Math.abs(delta.top) >= Math.abs(delta.left) ? delta.top < 0 ? "up" : "down" : delta.left < 0 ? "left" : "right";
			scroll.position = {
				top,
				left
			};
			scroll.directionChanged = scroll.direction !== curDir;
			scroll.delta = delta;
			if (scroll.directionChanged === true) {
				scroll.direction = curDir;
				scroll.inflectionPoint = scroll.position;
			}
			emit("scroll", { ...scroll });
		}
		function configureScrollTarget() {
			localScrollTarget = getScrollTarget(parentEl, props.scrollTarget);
			localScrollTarget.addEventListener("scroll", trigger, passive);
			trigger(true);
		}
		function unconfigureScrollTarget() {
			if (localScrollTarget !== void 0) {
				localScrollTarget.removeEventListener("scroll", trigger, passive);
				localScrollTarget = void 0;
			}
		}
		function trigger(immediately) {
			if (immediately === true || props.debounce === 0 || props.debounce === "0") emitEvent();
			else if (clearTimer === null) {
				const [timer, fn] = props.debounce ? [setTimeout(emitEvent, props.debounce), clearTimeout] : [requestAnimationFrame(emitEvent), cancelAnimationFrame];
				clearTimer = () => {
					fn(timer);
					clearTimer = null;
				};
			}
		}
		const { proxy } = getCurrentInstance();
		watch(() => proxy.$q.lang.rtl, emitEvent);
		onMounted(() => {
			parentEl = proxy.$el.parentNode;
			configureScrollTarget();
		});
		onBeforeUnmount(() => {
			clearTimer?.();
			unconfigureScrollTarget();
		});
		Object.assign(proxy, {
			trigger,
			getPosition: () => scroll
		});
		return noop;
	}
});
//#endregion
//#region node_modules/quasar/src/composables/use-hydration/use-hydration.js
function use_hydration_default() {
	const isHydrated = ref(!isRuntimeSsrPreHydration.value);
	if (isHydrated.value === false) onMounted(() => {
		isHydrated.value = true;
	});
	return { isHydrated };
}
//#endregion
//#region node_modules/quasar/src/components/resize-observer/QResizeObserver.js
var hasObserver = typeof ResizeObserver !== "undefined";
var resizeProps = hasObserver === true ? {} : {
	style: "display:block;position:absolute;top:0;left:0;right:0;bottom:0;height:100%;width:100%;overflow:hidden;pointer-events:none;z-index:-1;",
	url: "about:blank"
};
var QResizeObserver_default = createComponent({
	name: "QResizeObserver",
	props: { debounce: {
		type: [String, Number],
		default: 100
	} },
	emits: ["resize"],
	setup(props, { emit }) {
		let timer = null, targetEl, size = {
			width: -1,
			height: -1
		};
		function trigger(immediately) {
			if (immediately === true || props.debounce === 0 || props.debounce === "0") emitEvent();
			else if (timer === null) timer = setTimeout(emitEvent, props.debounce);
		}
		function emitEvent() {
			if (timer !== null) {
				clearTimeout(timer);
				timer = null;
			}
			if (targetEl) {
				const { offsetWidth: width, offsetHeight: height } = targetEl;
				if (width !== size.width || height !== size.height) {
					size = {
						width,
						height
					};
					emit("resize", size);
				}
			}
		}
		const { proxy } = getCurrentInstance();
		proxy.trigger = trigger;
		if (hasObserver === true) {
			let observer;
			const init = (stop) => {
				targetEl = proxy.$el.parentNode;
				if (targetEl) {
					observer = new ResizeObserver(trigger);
					observer.observe(targetEl);
					emitEvent();
				} else if (stop !== true) nextTick(() => {
					init(true);
				});
			};
			onMounted(() => {
				init();
			});
			onBeforeUnmount(() => {
				timer !== null && clearTimeout(timer);
				if (observer !== void 0) {
					if (observer.disconnect !== void 0) observer.disconnect();
					else if (targetEl) observer.unobserve(targetEl);
				}
			});
			return noop;
		} else {
			const { isHydrated } = use_hydration_default();
			let curDocView;
			function cleanup() {
				if (timer !== null) {
					clearTimeout(timer);
					timer = null;
				}
				if (curDocView !== void 0) {
					if (curDocView.removeEventListener !== void 0) curDocView.removeEventListener("resize", trigger, listenOpts.passive);
					curDocView = void 0;
				}
			}
			function onObjLoad() {
				cleanup();
				if (targetEl?.contentDocument) {
					curDocView = targetEl.contentDocument.defaultView;
					curDocView.addEventListener("resize", trigger, listenOpts.passive);
					emitEvent();
				}
			}
			onMounted(() => {
				nextTick(() => {
					targetEl = proxy.$el;
					targetEl && onObjLoad();
				});
			});
			onBeforeUnmount(cleanup);
			return () => {
				if (isHydrated.value === true) return h("object", {
					class: "q--avoid-card-border",
					style: resizeProps.style,
					tabindex: -1,
					type: "text/html",
					data: resizeProps.url,
					"aria-hidden": "true",
					onLoad: onObjLoad
				});
			};
		}
	}
});
//#endregion
export { QScrollObserver_default as n, QResizeObserver_default as t };

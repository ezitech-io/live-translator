import { _ as defineComponent, d as createBaseVNode, g as createVNode, j as openBlock, m as createElementBlock } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import "./dom-ClQ5j7De.js";
import "./vm-BBDykFtW.js";
import { r as QBtn_default } from "./index-Bj8rJPTG.js";
//#region src/pages/ErrorNotFound.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "fullscreen bg-blue text-white text-center q-pa-md flex flex-center" };
//#endregion
//#region src/pages/ErrorNotFound.vue
var ErrorNotFound_default = /* @__PURE__ */ defineComponent({
	__name: "ErrorNotFound",
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", null, [
				_cache[0] || (_cache[0] = createBaseVNode("div", { style: { "font-size": "30vh" } }, "404", -1)),
				_cache[1] || (_cache[1] = createBaseVNode("div", {
					class: "text-h2",
					style: { "opacity": "0.4" }
				}, "Oops. Nothing here...", -1)),
				createVNode(QBtn_default, {
					class: "q-mt-xl",
					color: "white",
					"text-color": "blue",
					unelevated: "",
					to: "/",
					label: "Go Home",
					"no-caps": ""
				})
			])]);
		};
	}
});
//#endregion
export { ErrorNotFound_default as default };

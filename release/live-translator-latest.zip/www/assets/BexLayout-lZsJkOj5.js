import { F as watch, G as ref, I as withCtx, M as provide, P as resolveComponent, W as reactive, f as createBlock, g as createVNode, j as openBlock, k as onUnmounted, u as computed, v as getCurrentInstance, x as inject, y as h } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import { a as hMergeSlot, b as createComponent, s as hSlot } from "./dom-ClQ5j7De.js";
import { r as isRuntimeSsrPreHydration } from "./Platform-DVLU8Kjq.js";
import { C as pageContainerKey, S as layoutKey, y as emptyRenderFn } from "./index-CycMF3Xu.js";
import { i as getScrollbarWidth, t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
import { n as QScrollObserver_default, t as QResizeObserver_default } from "./QResizeObserver-y6jkY3kf.js";
//#region node_modules/quasar/src/components/page/QPageContainer.js
var QPageContainer_default = createComponent({
	name: "QPageContainer",
	setup(_, { slots }) {
		const { proxy: { $q } } = getCurrentInstance();
		const $layout = inject(layoutKey, emptyRenderFn);
		if ($layout === emptyRenderFn) {
			console.error("QPageContainer needs to be child of QLayout");
			return emptyRenderFn;
		}
		provide(pageContainerKey, true);
		const style = computed(() => {
			const css = {};
			if ($layout.header.space === true) css.paddingTop = `${$layout.header.size}px`;
			if ($layout.right.space === true) css[`padding${$q.lang.rtl === true ? "Left" : "Right"}`] = `${$layout.right.size}px`;
			if ($layout.footer.space === true) css.paddingBottom = `${$layout.footer.size}px`;
			if ($layout.left.space === true) css[`padding${$q.lang.rtl === true ? "Right" : "Left"}`] = `${$layout.left.size}px`;
			return css;
		});
		return () => h("div", {
			class: "q-page-container",
			style: style.value
		}, hSlot(slots.default));
	}
});
//#endregion
//#region node_modules/quasar/src/components/layout/QLayout.js
var QLayout_default = createComponent({
	name: "QLayout",
	props: {
		container: Boolean,
		view: {
			type: String,
			default: "hhh lpr fff",
			validator: (v) => /^(h|l)h(h|r) lpr (f|l)f(f|r)$/.test(v.toLowerCase())
		},
		onScroll: Function,
		onScrollHeight: Function,
		onResize: Function
	},
	setup(props, { slots, emit }) {
		const { proxy: { $q } } = getCurrentInstance();
		const rootRef = ref(null);
		const height = ref($q.screen.height);
		const width = ref(props.container === true ? 0 : $q.screen.width);
		const scroll = ref({
			position: 0,
			direction: "down",
			inflectionPoint: 0
		});
		const containerHeight = ref(0);
		const scrollbarWidth = ref(isRuntimeSsrPreHydration.value === true ? 0 : getScrollbarWidth());
		const classes = computed(() => "q-layout q-layout--" + (props.container === true ? "containerized" : "standard"));
		const style = computed(() => props.container === false ? { minHeight: $q.screen.height + "px" } : null);
		const targetStyle = computed(() => scrollbarWidth.value !== 0 ? { [$q.lang.rtl === true ? "left" : "right"]: `${scrollbarWidth.value}px` } : null);
		const targetChildStyle = computed(() => scrollbarWidth.value !== 0 ? {
			[$q.lang.rtl === true ? "right" : "left"]: 0,
			[$q.lang.rtl === true ? "left" : "right"]: `-${scrollbarWidth.value}px`,
			width: `calc(100% + ${scrollbarWidth.value}px)`
		} : null);
		function onPageScroll(data) {
			if (props.container === true || document.qScrollPrevented !== true) {
				const info = {
					position: data.position.top,
					direction: data.direction,
					directionChanged: data.directionChanged,
					inflectionPoint: data.inflectionPoint.top,
					delta: data.delta.top
				};
				scroll.value = info;
				props.onScroll !== void 0 && emit("scroll", info);
			}
		}
		function onPageResize(data) {
			const { height: newHeight, width: newWidth } = data;
			let resized = false;
			if (height.value !== newHeight) {
				resized = true;
				height.value = newHeight;
				props.onScrollHeight !== void 0 && emit("scrollHeight", newHeight);
				updateScrollbarWidth();
			}
			if (width.value !== newWidth) {
				resized = true;
				width.value = newWidth;
			}
			if (resized === true && props.onResize !== void 0) emit("resize", data);
		}
		function onContainerResize({ height }) {
			if (containerHeight.value !== height) {
				containerHeight.value = height;
				updateScrollbarWidth();
			}
		}
		function updateScrollbarWidth() {
			if (props.container === true) {
				const width = height.value > containerHeight.value ? getScrollbarWidth() : 0;
				if (scrollbarWidth.value !== width) scrollbarWidth.value = width;
			}
		}
		let animateTimer = null;
		const $layout = {
			instances: {},
			view: computed(() => props.view),
			isContainer: computed(() => props.container),
			rootRef,
			height,
			containerHeight,
			scrollbarWidth,
			totalWidth: computed(() => width.value + scrollbarWidth.value),
			rows: computed(() => {
				const rows = props.view.toLowerCase().split(" ");
				return {
					top: rows[0].split(""),
					middle: rows[1].split(""),
					bottom: rows[2].split("")
				};
			}),
			header: reactive({
				size: 0,
				offset: 0,
				space: false
			}),
			right: reactive({
				size: 300,
				offset: 0,
				space: false
			}),
			footer: reactive({
				size: 0,
				offset: 0,
				space: false
			}),
			left: reactive({
				size: 300,
				offset: 0,
				space: false
			}),
			scroll,
			animate() {
				if (animateTimer !== null) clearTimeout(animateTimer);
				else document.body.classList.add("q-body--layout-animate");
				animateTimer = setTimeout(() => {
					animateTimer = null;
					document.body.classList.remove("q-body--layout-animate");
				}, 155);
			},
			update(part, prop, val) {
				$layout[part][prop] = val;
			}
		};
		provide(layoutKey, $layout);
		if (getScrollbarWidth() > 0) {
			let timer = null;
			const el = document.body;
			function restoreScrollbar() {
				timer = null;
				el.classList.remove("hide-scrollbar");
			}
			function hideScrollbar() {
				if (timer === null) {
					if (el.scrollHeight > $q.screen.height) return;
					el.classList.add("hide-scrollbar");
				} else clearTimeout(timer);
				timer = setTimeout(restoreScrollbar, 300);
			}
			function updateScrollEvent(action) {
				if (timer !== null && action === "remove") {
					clearTimeout(timer);
					restoreScrollbar();
				}
				window[`${action}EventListener`]("resize", hideScrollbar);
			}
			watch(() => props.container !== true ? "add" : "remove", updateScrollEvent);
			props.container !== true && updateScrollEvent("add");
			onUnmounted(() => {
				updateScrollEvent("remove");
			});
		}
		return () => {
			const content = hMergeSlot(slots.default, [h(QScrollObserver_default, { onScroll: onPageScroll }), h(QResizeObserver_default, { onResize: onPageResize })]);
			const layout = h("div", {
				class: classes.value,
				style: style.value,
				ref: props.container === true ? void 0 : rootRef,
				tabindex: -1
			}, content);
			if (props.container === true) return h("div", {
				class: "q-layout-container overflow-hidden",
				ref: rootRef
			}, [h(QResizeObserver_default, { onResize: onContainerResize }), h("div", {
				class: "absolute-full",
				style: targetStyle.value
			}, [h("div", {
				class: "scroll",
				style: targetChildStyle.value
			}, [layout])])]);
			return layout;
		};
	}
});
//#endregion
//#region src/layouts/BexLayout.vue
var _sfc_main = {};
function _sfc_render(_ctx, _cache) {
	const _component_router_view = resolveComponent("router-view");
	return openBlock(), createBlock(QLayout_default, {
		view: "hHh lpR fFf",
		class: "bex-layout"
	}, {
		default: withCtx(() => [createVNode(QPageContainer_default, null, {
			default: withCtx(() => [createVNode(_component_router_view)]),
			_: 1
		})]),
		_: 1
	});
}
var BexLayout_default = /* @__PURE__ */ _plugin_vue_export_helper_default(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-da009f7a"]]);
//#endregion
export { BexLayout_default as default };

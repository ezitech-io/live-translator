import { A as openBlock, g as defineComponent, h as createVNode, p as createElementBlock, u as createBaseVNode } from "./vue.runtime.esm-bundler-Da8D7169.js";
import "./dom-DvzD_91u.js";
import "./vm-BOuecwlZ.js";
import { r as QBtn_default } from "./index-DCYl0luy.js";
//#region src/pages/ErrorNotFound.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "fullscreen bg-blue text-white text-center q-pa-md flex flex-center" };
//#endregion
//#region src/pages/ErrorNotFound.vue
var ErrorNotFound_default = /* @__PURE__ */ defineComponent({
	__name: "ErrorNotFound",
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", null, [
				_cache[0] || (_cache[0] = createBaseVNode("div", { style: { "font-size": "30vh" } }, "404", -1)),
				_cache[1] || (_cache[1] = createBaseVNode("div", {
					class: "text-h2",
					style: { "opacity": "0.4" }
				}, "Oops. Nothing here...", -1)),
				createVNode(QBtn_default, {
					class: "q-mt-xl",
					color: "white",
					"text-color": "blue",
					unelevated: "",
					to: "/",
					label: "Go Home",
					"no-caps": ""
				})
			])]);
		};
	}
});
//#endregion
export { ErrorNotFound_default as default };

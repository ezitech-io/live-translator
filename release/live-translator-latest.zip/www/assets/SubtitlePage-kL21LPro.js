import { $ as normalizeStyle, F as watch, G as ref, I as withCtx, N as renderList, O as onMounted, Q as normalizeClass, S as nextTick, T as onBeforeUnmount, Z as unref, _ as defineComponent, d as createBaseVNode, et as toDisplayString, g as createVNode, h as createTextVNode, j as openBlock, m as createElementBlock, n as Transition, p as createCommentVNode, s as Fragment, u as computed } from "./vue.runtime.esm-bundler-dwk6Qeub.js";
import "./dom-ClQ5j7De.js";
import "./Platform-DVLU8Kjq.js";
import { i as QIcon_default } from "./vm-BBDykFtW.js";
import { m as storeToRefs } from "./index-CuPJw3L9.js";
import { n as useI18n } from "./vue-i18n.runtime-0_E2riTW.js";
import { t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-Xbx7mXmu.js";
import "./position-engine-DSsp2ZK0.js";
import { t as QTooltip_default } from "./QTooltip-wIWrNEKg.js";
import { t as useSettingsStore } from "./settings-store-B4lVmkzW.js";
import { n as useSubtitleSubscriber } from "./useSubtitleSync-DENG9ngW.js";
//#region src/pages/SubtitlePage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	class: "subtitle-toolbar",
	"data-no-drag": ""
};
var _hoisted_2 = ["aria-label"];
var _hoisted_3 = ["aria-label"];
var _hoisted_4 = {
	key: 0,
	class: "subtitle-settings",
	"data-no-drag": ""
};
var _hoisted_5 = { class: "subtitle-settings__row" };
var _hoisted_6 = { class: "subtitle-settings__label" };
var _hoisted_7 = ["value"];
var _hoisted_8 = { class: "subtitle-settings__value" };
var _hoisted_9 = { class: "subtitle-settings__row" };
var _hoisted_10 = { class: "subtitle-settings__label" };
var _hoisted_11 = { class: "subtitle-font-group" };
var _hoisted_12 = ["onClick"];
//#endregion
//#region src/pages/SubtitlePage.vue
var SubtitlePage_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "SubtitlePage",
	setup(__props) {
		const settingsStore = useSettingsStore();
		const { subtitleFontSize, subtitleOpacity } = storeToRefs(settingsStore);
		const { lines } = useSubtitleSubscriber();
		const { t } = useI18n();
		const scrollRef = ref(null);
		const isSettingsOpen = ref(false);
		let isDragging = false;
		const fontSizeOptions = [
			{
				value: "small",
				label: "translator.fontSizeSmall",
				iconClass: "subtitle-font-btn--small"
			},
			{
				value: "medium",
				label: "translator.fontSizeMedium",
				iconClass: "subtitle-font-btn--medium"
			},
			{
				value: "large",
				label: "translator.fontSizeLarge",
				iconClass: "subtitle-font-btn--large"
			}
		];
		const fontClass = computed(() => `subtitle-text--${subtitleFontSize.value}`);
		const glassStyle = computed(() => ({ background: `rgba(12, 12, 20, ${(subtitleOpacity.value / 100).toFixed(2)})` }));
		watch(() => lines.value.length, () => {
			nextTick(() => {
				const el = scrollRef.value;
				if (el) el.scrollTop = el.scrollHeight;
			});
		});
		function sendPanelMessage(message) {
			try {
				window.parent.postMessage(message, "*");
			} catch {}
		}
		function handleClose() {
			stopDrag(false);
			sendPanelMessage({ type: "SUBTITLE_MODE_OFF" });
		}
		function handleTitleBarMouseDown(event) {
			if (event.button !== 0) return;
			if (event.target?.closest("button, [role=\"button\"], [data-no-drag]")) return;
			event.preventDefault();
			isDragging = true;
			sendPanelMessage({
				type: "SUBTITLE_DRAG_START",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
			window.addEventListener("mousemove", handleMouseMove);
			window.addEventListener("mouseup", handleMouseUp);
		}
		function handleMouseMove(event) {
			if (!isDragging) return;
			sendPanelMessage({
				type: "SUBTITLE_DRAG_MOVE",
				localClientX: event.clientX,
				localClientY: event.clientY
			});
		}
		function handleMouseUp() {
			stopDrag(true);
		}
		function stopDrag(notify) {
			if (!isDragging) return;
			isDragging = false;
			window.removeEventListener("mousemove", handleMouseMove);
			window.removeEventListener("mouseup", handleMouseUp);
			if (notify) sendPanelMessage({ type: "SUBTITLE_DRAG_END" });
		}
		function handleFontSizeSelect(size) {
			settingsStore.subtitleFontSize = size;
		}
		function handleOpacityChange(value) {
			settingsStore.subtitleOpacity = Math.max(10, Math.min(100, value));
		}
		onMounted(async () => {
			await settingsStore.loadSettings();
			sendPanelMessage({ type: "SUBTITLE_READY" });
		});
		onBeforeUnmount(() => {
			stopDrag(true);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "subtitle-page",
				style: normalizeStyle(glassStyle.value),
				onMousedown: handleTitleBarMouseDown
			}, [
				createBaseVNode("div", _hoisted_1, [createBaseVNode("button", {
					class: "subtitle-tool-btn",
					"data-no-drag": "",
					"aria-label": unref(t)("translator.subtitleSettings"),
					onClick: _cache[0] || (_cache[0] = ($event) => isSettingsOpen.value = !isSettingsOpen.value)
				}, [createVNode(QIcon_default, {
					name: "tune",
					size: "16px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("translator.subtitleSettings")), 1)]),
					_: 1
				})], 8, _hoisted_2), createBaseVNode("button", {
					class: "subtitle-tool-btn subtitle-tool-btn--close",
					"data-no-drag": "",
					"aria-label": unref(t)("translator.subtitleClose"),
					onClick: handleClose
				}, [createVNode(QIcon_default, {
					name: "close",
					size: "16px"
				}), createVNode(QTooltip_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("translator.subtitleClose")), 1)]),
					_: 1
				})], 8, _hoisted_3)]),
				createVNode(Transition, { name: "settings-slide" }, {
					default: withCtx(() => [isSettingsOpen.value ? (openBlock(), createElementBlock("div", _hoisted_4, [createBaseVNode("div", _hoisted_5, [
						createBaseVNode("span", _hoisted_6, toDisplayString(unref(t)("translator.subtitleOpacity")), 1),
						createBaseVNode("input", {
							type: "range",
							class: "subtitle-opacity-slider",
							min: 10,
							max: 100,
							value: unref(subtitleOpacity),
							onInput: _cache[1] || (_cache[1] = ($event) => handleOpacityChange(Number($event.target.value)))
						}, null, 40, _hoisted_7),
						createBaseVNode("span", _hoisted_8, toDisplayString(unref(subtitleOpacity)) + "%", 1)
					]), createBaseVNode("div", _hoisted_9, [createBaseVNode("span", _hoisted_10, toDisplayString(unref(t)("translator.fontSize")), 1), createBaseVNode("div", _hoisted_11, [(openBlock(), createElementBlock(Fragment, null, renderList(fontSizeOptions, (opt) => {
						return createBaseVNode("button", {
							key: opt.value,
							class: normalizeClass(["subtitle-font-btn", [opt.iconClass, { "subtitle-font-btn--active": unref(subtitleFontSize) === opt.value }]]),
							onClick: ($event) => handleFontSizeSelect(opt.value)
						}, [createVNode(QIcon_default, { name: "format_size" }), createVNode(QTooltip_default, null, {
							default: withCtx(() => [createTextVNode(toDisplayString(unref(t)(opt.label)), 1)]),
							_: 2
						}, 1024)], 10, _hoisted_12);
					}), 64))])])])) : createCommentVNode("", true)]),
					_: 1
				}),
				createBaseVNode("div", {
					ref_key: "scrollRef",
					ref: scrollRef,
					class: normalizeClass(["subtitle-scroll", fontClass.value])
				}, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(lines), (line) => {
					return openBlock(), createElementBlock("div", {
						key: line.id,
						class: "subtitle-line",
						role: "status",
						"aria-live": "polite"
					}, toDisplayString(line.text), 1);
				}), 128))], 2)
			], 36);
		};
	}
}), [["__scopeId", "data-v-53521bf3"]]);
//#endregion
export { SubtitlePage_default as default };
